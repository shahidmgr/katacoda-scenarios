/**
 * Created by dan.geabunea on 3/29/2016.
 */
(function(){
    'use strict';

    angular.module('app', []);
})();
